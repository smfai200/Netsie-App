class Product {
  String name;
  String type;
  String imgUrl;
  String price;

  Product(this.name, this.type, this.imgUrl, this.price);
}

var products = [Product("BMW K30", "Bicyle", "assets/images/bike.png", "999")];
