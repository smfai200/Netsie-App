import 'package:flutter/material.dart';

class CustomIcons {
  static final IconData arrow = IconData(0xe900, fontFamily: "customIcons");
  static final IconData cart = IconData(0xe901, fontFamily: "customIcons");
}
